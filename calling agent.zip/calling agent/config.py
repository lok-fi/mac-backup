from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    gemini_api_key: str = "AIzaSyCso5BkK-NOVapxKczSfyOm_IHsk7LbH3U"
    sarvam_api_key: str = "sk_dyh96c1e_pfguWinEAcJ9xo5N6J16AiYA"
    twilio_account_sid: str = "AC716692ef0b9a7e60e83af7df093cb386"
    twilio_auth_token: str = "a9cd92ef1527ccb4201e59db32543ef4"
    twilio_phone_number: str = "+18166536617"
    server_host: str = "6348-27-107-69-106.ngrok-free.app"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
