/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { 
  LayoutDashboard, 
  ShoppingBag, 
  FileText, 
  CheckSquare, 
  User,
  Bell,
  Search,
  ChevronDown,
  Plus,
  Trash2,
  X,
  ArrowRight,
  Package,
  Calendar,
  MapPin,
  CircleCheck,
  Clock,
  AlertCircle,
  Truck,
  Upload,
  FileUp,
  Activity,
  History
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type Tab = 'dashboard' | 'orders' | 'invoices' | 'grm' | 'profile' | 'privacy' | 'terms';

const CREDIT_LIMIT = 5000;
const AVAILABLE_CREDIT = 4500;

interface LineItem {
  id: string;
  productName: string;
  sku: string;
  technicalName: string;
  quantity: number;
  billingPrice: number;
  discountPrice: number;
}

interface Order {
  id: string;
  distributorName: string;
  email: string;
  orderType: string;
  territory: string;
  description: string;
  orderDate: string;
  contactName: string;
  contactNumber: string;
  dueDate: string;
  creditBalance: string;
  plant: string;
  status: 'Pending' | 'Shipped' | 'Delivered' | 'Draft';
  billingAddress: Address;
  shippingAddress: Address;
  isShippingSameAsBilling: boolean;
  items: LineItem[];
  subtotal: number;
  grandTotal: number;
  epodSubmitted?: boolean;
  trackingStages: TrackingStage[];
  currentStageIndex: number;
}

interface TrackingStage {
  label: string;
  status: 'completed' | 'current' | 'pending';
  timestamp?: string;
  location?: string;
  isStepAtDoorstep?: boolean;
}

interface Invoice {
  id: string;
  invoiceNumber: string;
  sapId: string;
  invoiceDate: string;
  distributorName: string;
  status: 'Approved' | 'Pending' | 'Paid';
  grandTotal: number;
  orderId: string;
}

interface Address {
  street: string;
  city: string;
  state: string;
  country: string;
  zipCode: string;
}

const INITIAL_ORDERS: Order[] = [
  {
    id: 'ORD-2026-001',
    distributorName: 'Lokesh Prasad',
    email: 'lokesh.p@distributor.upl.com',
    orderType: 'Standard Bulk',
    territory: 'Maharashtra Rural',
    description: 'Pre-monsoon fertilizer stock up',
    orderDate: '2026-05-01',
    contactName: 'Lokesh Prasad',
    contactNumber: '+91 98765 43210',
    dueDate: '2026-05-20',
    creditBalance: '$4,50,000',
    plant: 'Vapi - Plant 1',
    status: 'Delivered',
    billingAddress: { street: 'Main Arcade, Block B', city: 'Mumbai', state: 'Maharashtra', country: 'India', zipCode: '400001' },
    shippingAddress: { street: 'Main Arcade, Block B', city: 'Mumbai', state: 'Maharashtra', country: 'India', zipCode: '400001' },
    isShippingSameAsBilling: true,
    items: [
      { id: '1', productName: 'PHOSKILL 50% EC', sku: 'UPL-INS-001', technicalName: 'Monocrotophos', quantity: 200, billingPrice: 450, discountPrice: 22.5 },
      { id: '2', productName: 'MANZATE MAX', sku: 'UPL-FUN-002', technicalName: 'Mancozeb', quantity: 150, billingPrice: 320, discountPrice: 16 }
    ],
    subtotal: 125000,
    grandTotal: 147500,
    trackingStages: [
      { label: 'Order Confirmed', status: 'completed', timestamp: '2026-05-01 10:00 AM', location: 'System' },
      { label: 'Processing', status: 'completed', timestamp: '2026-05-01 02:30 PM', location: 'Vapi Plant' },
      { label: 'Shipped', status: 'completed', timestamp: '2026-05-02 09:15 AM', location: 'Vapi Dispatch' },
      { label: 'Out for Delivery', status: 'completed', timestamp: '2026-05-05 08:30 AM', location: 'Main Hub' },
      { label: 'Delivered', status: 'completed', timestamp: '2026-05-05 04:45 PM', location: 'Delivery Point', isStepAtDoorstep: true }
    ],
    currentStageIndex: 4
  },
  {
    id: 'ORD-2026-002',
    distributorName: 'Lokesh Prasad',
    email: 'lokesh.p@distributor.upl.com',
    orderType: 'Urgent Pesticide',
    territory: 'Gujarat North',
    description: 'Emergency pest control supply',
    orderDate: '2026-05-08',
    contactName: 'Lokesh Prasad',
    contactNumber: '+91 98765 43210',
    dueDate: '2026-05-15',
    creditBalance: '$4,50,000',
    plant: 'Ankleshwar',
    status: 'Shipped',
    billingAddress: { street: 'Main Arcade, Block B', city: 'Mumbai', state: 'Maharashtra', country: 'India', zipCode: '400001' },
    shippingAddress: { street: 'Gujarat Warehouse 4', city: 'Surat', state: 'Gujarat', country: 'India', zipCode: '395003' },
    isShippingSameAsBilling: false,
    items: [
      { id: '1', productName: 'ULALA', sku: 'UPL-INS-004', technicalName: 'Flonicamid', quantity: 80, billingPrice: 1250, discountPrice: 62.5 }
    ],
    subtotal: 84000,
    grandTotal: 99120,
    trackingStages: [
      { label: 'Order Confirmed', status: 'completed', timestamp: '2026-05-08 11:30 AM', location: 'System' },
      { label: 'Processing', status: 'completed', timestamp: '2026-05-08 03:00 PM', location: 'Ankleshwar Plant' },
      { label: 'Shipped', status: 'completed', timestamp: '2026-05-09 10:00 AM', location: 'Dispatch Yard' },
      { label: 'At Doorstep', status: 'current', timestamp: '2026-05-11 09:00 AM', location: 'Final Delivery Zone', isStepAtDoorstep: true },
      { label: 'Delivered', status: 'pending' }
    ],
    currentStageIndex: 3
  }
];

const INITIAL_INVOICES: Invoice[] = [
  {
    id: '3413350000002437166',
    invoiceNumber: 'INV-6078-1',
    sapId: '4511590003',
    invoiceDate: '2026-05-08',
    distributorName: 'Lokesh Prasad',
    status: 'Approved',
    grandTotal: 147500,
    orderId: 'ORD-2026-001'
  },
  {
    id: '3413350000002399004',
    invoiceNumber: 'INV-6078-2',
    sapId: '4501500021',
    invoiceDate: '2026-05-05',
    distributorName: 'Lokesh Prasad',
    status: 'Approved',
    grandTotal: 99120,
    orderId: 'ORD-2026-002'
  }
];

interface Product {
  name: string;
  sku: string;
  technicalName: string;
  basePrice: number;
}

const PREDEFINED_PRODUCTS: Product[] = [
  { name: 'PHOSKILL 50% EC', sku: 'UPL-INS-001', technicalName: 'Monocrotophos', basePrice: 450 },
  { name: 'MANZATE MAX', sku: 'UPL-FUN-002', technicalName: 'Mancozeb', basePrice: 320 },
  { name: 'GLYPHOSATE 41% SL', sku: 'UPL-HER-003', technicalName: 'Glyphosate', basePrice: 280 },
  { name: 'ULALA', sku: 'UPL-INS-004', technicalName: 'Flonicamid', basePrice: 1250 },
  { name: 'SAAF', sku: 'UPL-FUN-005', technicalName: 'Carbendazim + Mancozeb', basePrice: 580 },
  { name: 'MACARENA', sku: 'UPL-FUN-006', technicalName: 'Azoxystrobin + Pyraclostrobin', basePrice: 1850 },
  { name: 'LANCER GOLD', sku: 'UPL-INS-007', technicalName: 'Acephate + Imidacloprid', basePrice: 940 },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [invoices, setInvoices] = useState<Invoice[]>(INITIAL_INVOICES);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [selectedTrackingOrderId, setSelectedTrackingOrderId] = useState<string | null>(INITIAL_ORDERS.find(o => o.status === 'Shipped')?.id || null);
  const [isAddingOrder, setIsAddingOrder] = useState(false);
  const [highlightedOrderId, setHighlightedOrderId] = useState<string | null>(null);
  const [liveAlerts] = useState([
    { id: '1', type: 'info', message: 'New monsoon promotion starts next week!', date: 'Just now' },
    { id: '2', type: 'warning', message: 'Vapi plant running at 110% capacity - expect faster delivery.', date: '2 hours ago' },
    { id: '3', type: 'success', message: 'Your payment for INV-6088 has been verified.', date: '5 hours ago' },
  ]);

  // Clear highlight after 3 seconds
  useEffect(() => {
    if (highlightedOrderId) {
      const timer = setTimeout(() => {
        setHighlightedOrderId(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [highlightedOrderId]);

  // Form State
  const [formData, setFormData] = useState<Partial<Order>>({
    distributorName: 'Lokesh Prasad',
    email: 'lokesh.p@distributor.upl.com',
    orderDate: new Date().toISOString().split('T')[0],
    isShippingSameAsBilling: true,
    billingAddress: { street: '', city: '', state: '', country: '', zipCode: '' },
    shippingAddress: { street: '', city: '', state: '', country: '', zipCode: '' },
    items: [{ id: '1', productName: '', sku: '', technicalName: '', quantity: 1, billingPrice: 0, discountPrice: 0 }]
  });

  const calculateTotals = (items: LineItem[]) => {
    const subtotal = items.reduce((acc, item) => acc + (item.quantity * (item.billingPrice - item.discountPrice)), 0);
    const cgst = subtotal * 0.09;
    const sgst = subtotal * 0.09;
    const igst = subtotal * 0.13; // Example IGST
    const tax = cgst + sgst;
    const total = subtotal + tax;
    return { subtotal, tax, total, cgst, sgst, igst };
  };

  const handleEpodUpload = (orderId: string) => {
    setOrders(prev => prev.map(order => {
      if (order.id === orderId) {
        const newStages = [...order.trackingStages];
        // Mark current as completed
        if (newStages[order.currentStageIndex]) {
          newStages[order.currentStageIndex].status = 'completed';
          newStages[order.currentStageIndex].timestamp = new Date().toLocaleString();
        }
        // Move to next stage (Delivered)
        const nextIndex = order.currentStageIndex + 1;
        if (newStages[nextIndex]) {
          newStages[nextIndex].status = 'completed';
          newStages[nextIndex].timestamp = new Date().toLocaleString();
          newStages[nextIndex].location = 'Your Warehouse';
        }
        
        return {
          ...order,
          status: 'Delivered',
          epodSubmitted: true,
          currentStageIndex: nextIndex,
          trackingStages: newStages
        };
      }
      return order;
    }));
  };

  const totals = useMemo(() => calculateTotals((formData.items || []) as LineItem[]), [formData.items]);

  const chartData = useMemo(() => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentYear = new Date().getFullYear();
    
    // Initialize data for last 6 months
    const data: Record<string, { month: string, total: number }> = {};
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const m = months[d.getMonth()];
      data[m] = { month: m, total: 0 };
    }

    orders.forEach(order => {
      const date = new Date(order.orderDate);
      const m = months[date.getMonth()];
      if (data[m]) {
        data[m].total += order.grandTotal;
      }
    });

    return Object.values(data);
  }, [orders]);

  const salesData = useMemo(() => {
    const aggregated: Record<string, {
      productName: string;
      sku: string;
      technicalName: string;
      totalQuantity: number;
      totalAmount: number;
      totalDiscount: number;
      orders: string[];
    }> = {};

    orders.forEach(order => {
      order.items.forEach(item => {
        if (!aggregated[item.sku]) {
          aggregated[item.sku] = {
            productName: item.productName,
            sku: item.sku,
            technicalName: item.technicalName,
            totalQuantity: 0,
            totalAmount: 0,
            totalDiscount: 0,
            orders: []
          };
        }
        aggregated[item.sku].totalQuantity += item.quantity;
        aggregated[item.sku].totalAmount += (item.billingPrice - item.discountPrice) * item.quantity;
        aggregated[item.sku].totalDiscount += item.discountPrice * item.quantity;
        if (!aggregated[item.sku].orders.includes(order.id)) {
          aggregated[item.sku].orders.push(order.id);
        }
      });
    });

    return Object.values(aggregated);
  }, [orders]);

  const currentAvailableCredit = useMemo(() => {
    const pendingAmount = orders.reduce((acc, o) => o.status === 'Pending' ? acc + o.grandTotal : acc, 0);
    return AVAILABLE_CREDIT - pendingAmount;
  }, [orders]);

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (totals.total > currentAvailableCredit) {
      alert("Error: Order total exceeds available credit limit. Please reduce quantity or settle pending invoices.");
      return;
    }
    const orderId = `ORD-${new Date().getFullYear()}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
    const newOrder: Order = {
      ...formData as Order,
      id: orderId,
      status: 'Pending',
      subtotal: totals.subtotal,
      grandTotal: totals.total,
      currentStageIndex: 0,
      trackingStages: [
        { label: 'Order Confirmed', status: 'current', timestamp: new Date().toLocaleString(), location: 'System' },
        { label: 'Processing', status: 'pending' },
        { label: 'Shipped', status: 'pending' },
        { label: 'At Doorstep', status: 'pending', isStepAtDoorstep: true },
        { label: 'Delivered', status: 'pending' }
      ]
    };

    const newInvoice: Invoice = {
      id: Math.random().toString(10).slice(2, 21),
      invoiceNumber: `INV-${Math.floor(Math.random() * 10000)}-${Math.floor(Math.random() * 10)}`,
      sapId: `4501${Math.floor(Math.random() * 100000)}`,
      invoiceDate: new Date().toISOString().split('T')[0],
      distributorName: formData.distributorName || 'Lokesh Prasad',
      status: 'Pending',
      grandTotal: totals.total,
      orderId: orderId
    };

    setOrders([newOrder, ...orders]);
    setInvoices([newInvoice, ...invoices]);
    setIsAddingOrder(false);
  };

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'orders', label: 'Orders', icon: ShoppingBag },
    { id: 'invoices', label: 'Invoices', icon: FileText },
    { id: 'grm', label: 'GRM', icon: CheckSquare },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <div className="flex items-center">
              <video 
                src="https://www.upl-ltd.com/images/UPL_header-logo.mp4"
                autoPlay 
                loop 
                muted 
                playsInline
                className="h-14 w-auto object-contain"
              />
            </div>

            {/* Navigation Tabs */}
            <nav className="hidden md:flex items-center gap-1">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as Tab)}
                    className={`
                      relative px-6 py-2 rounded-full text-sm font-semibold transition-all duration-300 flex items-center gap-2
                      ${isActive 
                        ? 'text-upl-blue bg-blue-50' 
                        : 'text-slate-500 hover:text-upl-blue hover:bg-slate-50'}
                    `}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-upl-orange' : ''}`} />
                    {tab.label}
                    {isActive && (
                      <motion.div
                        layoutId="activeTab"
                        className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-1 bg-upl-orange rounded-full"
                        transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                      />
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Right Actions */}
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex items-center gap-2 mr-2">
                <button className="p-2 text-slate-400 hover:text-upl-blue transition-colors">
                  <Search className="w-5 h-5" />
                </button>
                <button className="p-2 text-slate-400 hover:text-upl-blue transition-colors relative">
                  <Bell className="w-5 h-5" />
                  <span className="absolute top-2 right-2 w-2 h-2 bg-upl-orange rounded-full border-2 border-white" />
                </button>
              </div>
              
              <div className="h-8 w-[1px] bg-slate-200 mx-1" />

              <button 
                onClick={() => setActiveTab('profile')}
                className={`
                  flex items-center gap-3 p-1 pl-3 rounded-full border transition-all
                  ${activeTab === 'profile' 
                    ? 'border-upl-blue bg-blue-50' 
                    : 'border-slate-200 hover:border-slate-300 bg-white'}
                `}
              >
                <div className="hidden sm:block text-right">
                  <p className="text-xs font-black text-upl-blue uppercase tracking-widest leading-none">Lokesh Prasad</p>
                </div>
                <div className="w-10 h-10 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-upl-blue">
                  <User className="w-6 h-6" />
                </div>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="w-full"
          >
            {activeTab === 'dashboard' && (
              <div className="space-y-8">
                <div className="flex flex-col gap-2">
                  <h1 className="text-3xl font-bold text-upl-blue">Dashboard Overview</h1>
                  <p className="text-slate-500">Welcome back, Lokesh. Here's a snapshot of your distribution network's performance.</p>
                </div>

                {/* Stat Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { label: 'Total Orders', value: orders.length.toString(), icon: ShoppingBag, color: 'text-blue-600', bg: 'bg-blue-50' },
                    { label: 'Pending GRM', value: '12', icon: CheckSquare, color: 'text-amber-600', bg: 'bg-amber-50' },
                    { label: 'Credit Limit', value: `$${CREDIT_LIMIT.toLocaleString()}`, icon: FileText, color: 'text-upl-blue', bg: 'bg-blue-50' },
                    { label: 'Available Credit', value: `$${(AVAILABLE_CREDIT - orders.reduce((acc, o) => o.status === 'Pending' ? acc + o.grandTotal : acc, 0)).toLocaleString()}`, icon: AlertCircle, color: 'text-red-600', bg: 'bg-red-50' },
                  ].map((stat) => (
                    <div key={stat.label} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-2xl ${stat.bg} ${stat.color} flex items-center justify-center`}>
                        <stat.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">{stat.label}</p>
                        <p className="text-xl font-black text-upl-blue">{stat.value}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Recent Orders Widget */}
                  <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                    <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                      <h3 className="font-bold text-upl-blue flex items-center gap-2">
                        <Clock className="w-5 h-5" />
                        Recent Orders
                      </h3>
                      <button onClick={() => setActiveTab('orders')} className="text-xs font-bold text-upl-orange hover:underline uppercase tracking-widest">View All</button>
                    </div>
                    <div className="divide-y divide-slate-100">
                      {orders.slice(0, 4).map((order) => (
                        <div key={order.id} className="p-4 hover:bg-slate-50 transition-colors flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400">
                              <Package className="w-5 h-5" />
                            </div>
                            <div>
                              <p className="text-sm font-bold text-upl-blue">{order.id}</p>
                              <p className="text-[10px] text-slate-500 font-medium">{order.orderDate} • {order.plant}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-black text-slate-900">${order.grandTotal.toLocaleString()}</p>
                            <span className={`text-[10px] font-bold ${order.status === 'Delivered' ? 'text-emerald-500' : 'text-amber-500'}`}>{order.status}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Summary Notifications & Live Alerts */}
                  <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-6">
                    <h3 className="font-bold text-upl-blue flex items-center gap-2 border-b border-slate-100 pb-4">
                      <Bell className="w-5 h-5 text-upl-orange" />
                      Live Network Alerts
                    </h3>
                    <div className="space-y-4">
                      {liveAlerts.map((alert) => (
                        <div key={alert.id} className={`p-4 rounded-2xl border flex gap-3 ${
                          alert.type === 'warning' ? 'bg-amber-50 border-amber-100' : 
                          alert.type === 'success' ? 'bg-emerald-50 border-emerald-100' : 
                          'bg-blue-50 border-blue-100'
                        }`}>
                          <div className={`p-2 rounded-xl bg-white shadow-sm flex-shrink-0`}>
                            {alert.type === 'warning' ? <AlertCircle className="w-4 h-4 text-amber-500" /> : 
                             alert.type === 'success' ? <CircleCheck className="w-4 h-4 text-emerald-500" /> : 
                             <Activity className="w-4 h-4 text-blue-500" />}
                          </div>
                          <div>
                            <p className={`text-xs font-bold ${
                              alert.type === 'warning' ? 'text-amber-700' : 
                              alert.type === 'success' ? 'text-emerald-700' : 
                              'text-blue-700'
                            }`}>{alert.message}</p>
                            <p className="text-[10px] text-slate-400 mt-1">{alert.date}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Visual Chart Placeholder */}
                <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-xl p-8 overflow-hidden relative group">
                  <div className="flex justify-between items-start mb-8">
                    <div>
                      <h3 className="text-xl font-black text-upl-blue italic uppercase tracking-tighter">Monthly Performance</h3>
                      <p className="text-xs text-slate-400 font-medium mt-1">Transaction volume across the digital network</p>
                    </div>
                    <div className="flex items-center gap-2">
                       <div className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5">
                        <ArrowRight className="w-3 h-3 -rotate-45" />
                        +12.4% vs Prev
                      </div>
                    </div>
                  </div>
                  
                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#002855" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#002855" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis 
                          dataKey="month" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                          dy={10}
                        />
                        <YAxis 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                        />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: '#002855', 
                            borderRadius: '16px', 
                            border: 'none',
                            color: '#fff',
                            boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)'
                          }}
                          itemStyle={{ color: '#fff', fontWeight: 900 }}
                          labelStyle={{ color: '#94a3b8', marginBottom: '4px', fontSize: '10px', textTransform: 'uppercase', fontWeight: 900 }}
                          formatter={(value: number) => [`$${value.toLocaleString()}`, 'Volume']}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="total" 
                          stroke="#002855" 
                          strokeWidth={4}
                          fillOpacity={1} 
                          fill="url(#colorTotal)" 
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Sales Overview Integration */}
                <div className="space-y-8 pt-8 border-t border-slate-200">
                  <div className="flex flex-col gap-2">
                    <h2 className="text-2xl font-black text-upl-blue italic uppercase tracking-tighter">Life-time Sales Analytics</h2>
                    <p className="text-slate-500 text-sm">Historical performance and product-level purchasing data log.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Lifetime Volume</p>
                      <p className="text-2xl font-black text-upl-blue">{salesData.reduce((acc, s) => acc + s.totalQuantity, 0).toLocaleString()} Units</p>
                    </div>
                    <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Portfolio Value</p>
                      <p className="text-2xl font-black text-upl-orange">${salesData.reduce((acc, s) => acc + s.totalAmount, 0).toLocaleString()}</p>
                    </div>
                    <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Active SKUs</p>
                      <p className="text-2xl font-black text-emerald-600 font-mono italic">{salesData.length}</p>
                    </div>
                  </div>

                  <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-xl overflow-hidden">
                    <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                      <h3 className="font-black text-upl-blue uppercase tracking-widest text-sm italic">Product-Level Order History</h3>
                      <div className="flex items-center gap-2 group">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Live Integration Sync</span>
                      </div>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left">
                        <thead>
                          <tr className="bg-slate-50/30 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
                            <th className="px-8 py-5">Product Details</th>
                            <th className="px-8 py-5 text-center">Lifetime Qty</th>
                            <th className="px-8 py-5">Avg Discount</th>
                            <th className="px-8 py-5">Associated Orders</th>
                            <th className="px-8 py-5 text-right">Total Invested</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                          {salesData.map((item) => (
                            <tr key={item.sku} className="hover:bg-slate-50/40 transition-colors">
                              <td className="px-8 py-6">
                                <p className="font-black text-upl-blue">{item.productName}</p>
                                <div className="flex items-center gap-2 mt-1">
                                  <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded uppercase">{item.sku}</span>
                                  <span className="text-[10px] text-slate-400 italic">| {item.technicalName}</span>
                                </div>
                              </td>
                              <td className="px-8 py-6 text-center">
                                <span className="px-4 py-2 bg-blue-50 text-upl-blue rounded-2xl font-black text-sm">
                                  {item.totalQuantity}
                                </span>
                              </td>
                              <td className="px-8 py-6 font-bold text-emerald-600">
                                ${(item.totalDiscount / item.totalQuantity).toFixed(2)}/u
                              </td>
                              <td className="px-8 py-6">
                                <div className="flex flex-wrap gap-1">
                                  {item.orders.map(oid => (
                                    <span key={oid} className="text-[9px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200">
                                      {oid}
                                    </span>
                                  ))}
                                </div>
                              </td>
                              <td className="px-8 py-6 text-right">
                                <p className="text-lg font-black text-slate-900">${item.totalAmount.toLocaleString()}</p>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'orders' && (
              <div className="space-y-6">
                <AnimatePresence mode="wait">
                  {!isAddingOrder ? (
                    <motion.div 
                      key="order-list"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="space-y-6"
                    >
                      <div className="flex justify-between items-center">
                        <div className="flex flex-col gap-2">
                          <h1 className="text-3xl font-bold text-upl-blue">Orders Management</h1>
                          <p className="text-slate-500">Track, manage and place new orders for products.</p>
                        </div>
                        <button 
                          onClick={() => setIsAddingOrder(true)}
                          className="bg-upl-orange text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-upl-orange/20 hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
                        >
                          <Plus className="w-5 h-5" />
                          Add Order
                        </button>
                      </div>

                      {/* Orders Table */}
                      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                        <div className="overflow-x-auto">
                          <table className="w-full text-left border-collapse">
                            <thead>
                              <tr className="bg-slate-50 border-b border-slate-200">
                                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Order ID</th>
                                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Date</th>
                                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Product Type</th>
                                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Amount</th>
                                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</th>
                                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Action</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                              {orders.map((order) => {
                                const isHighlighted = highlightedOrderId === order.id;
                                return (
                                  <motion.tr 
                                    key={order.id} 
                                    initial={false}
                                    animate={isHighlighted ? { 
                                      backgroundColor: ['rgba(255,255,255,1)', 'rgba(255,130,0,0.1)', 'rgba(255,255,255,1)'],
                                      boxShadow: ['none', 'inset 0 0 20px rgba(255,130,0,0.1)', 'none']
                                    } : {}}
                                    transition={{ duration: 1.5, repeat: isHighlighted ? 2 : 0 }}
                                    className={`hover:bg-slate-50/50 transition-colors group ${isHighlighted ? 'ring-2 ring-upl-orange ring-inset relative z-10' : ''}`}
                                  >
                                    <td className="px-6 py-4">
                                      <div className="flex items-center gap-3">
                                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${isHighlighted ? 'bg-upl-orange text-white' : 'bg-blue-50 text-upl-blue'}`}>
                                          <ShoppingBag className="w-4 h-4" />
                                        </div>
                                        <span className={`font-bold transition-colors ${isHighlighted ? 'text-upl-orange' : 'text-upl-blue'}`}>{order.id}</span>
                                      </div>
                                    </td>
                                    <td className="px-6 py-4 font-medium text-slate-600">{order.orderDate}</td>
                                    <td className="px-6 py-4 text-slate-600">{order.orderType}</td>
                                    <td className="px-6 py-4 font-bold text-slate-900">${order.grandTotal.toLocaleString()}</td>
                                    <td className="px-6 py-4">
                                      <span className={`
                                        inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider
                                        ${order.status === 'Delivered' ? 'bg-emerald-50 text-emerald-600' : ''}
                                        ${order.status === 'Shipped' ? 'bg-blue-50 text-blue-600' : ''}
                                        ${order.status === 'Pending' ? 'bg-amber-50 text-amber-600' : ''}
                                      `}>
                                        {order.status === 'Delivered' && <CircleCheck className="w-3 h-3" />}
                                        {order.status === 'Shipped' && <Package className="w-3 h-3" />}
                                        {order.status === 'Pending' && <Clock className="w-3 h-3" />}
                                        {order.status}
                                      </span>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                      <button 
                                        onClick={() => setSelectedOrder(order)}
                                        className="text-upl-blue p-2 hover:bg-blue-50 rounded-lg transition-colors"
                                      >
                                        <ArrowRight className="w-4 h-4" />
                                      </button>
                                    </td>
                                  </motion.tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                        {orders.length === 0 && (
                          <div className="p-20 flex flex-col items-center justify-center text-slate-400">
                            <ShoppingBag className="w-16 h-16 mb-4 opacity-10" />
                            <p className="text-lg font-medium">No orders found.</p>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div 
                      key="order-form"
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.98 }}
                      className="max-w-5xl mx-auto"
                    >
                      <div className="flex items-center justify-between mb-8">
                        <button 
                          onClick={() => setIsAddingOrder(false)}
                          className="group flex items-center gap-2 text-slate-500 hover:text-upl-blue font-bold px-4 py-2 rounded-xl transition-all"
                        >
                          <X className="w-5 h-5 group-hover:rotate-90 transition-transform" />
                          Cancel
                        </button>
                        <h2 className="text-2xl font-black text-upl-blue">New Order Creation</h2>
                        <div className="w-20" /> {/* Spacer */}
                      </div>

                      <form onSubmit={handleCreateOrder} className="space-y-6 pb-20">
                        {/* Section: Basic Details */}
                        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-8 space-y-6">
                          <div className="flex items-center gap-3 text-upl-blue pb-4 border-b border-slate-100">
                            <LayoutDashboard className="w-6 h-6 border-2 border-upl-blue rounded-lg p-0.5" />
                            <h3 className="font-bold text-lg">Basic Details</h3>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {[
                              { label: 'Distributor Name', value: formData.distributorName, readOnly: true },
                              { label: 'Email', value: formData.email, readOnly: true },
                              { label: 'Order Type', key: 'orderType', type: 'select', options: ['Standard', 'Urgent', 'Bulk', 'Promotion'] },
                              { label: 'Territory', key: 'territory', placeholder: 'e.g. Rajasthan North' },
                              { label: 'Order Date', key: 'orderDate', type: 'date' },
                              { label: 'Contact Name', key: 'contactName' },
                              { label: 'Contact Number', key: 'contactNumber' },
                              { label: 'Due Date', key: 'dueDate', type: 'date' },
                              { label: 'Credit Balance', key: 'creditBalance', placeholder: 'e.g. $5,00,000' },
                              { label: 'Plant', key: 'plant', placeholder: 'e.g. Jaipur Plant' },
                            ].map((field) => (
                              <div key={field.label} className="space-y-1.5 focus-within:ring-2 focus-within:ring-upl-blue/5 rounded-xl transition-all">
                                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 pl-1">{field.label}</label>
                                {field.type === 'select' ? (
                                  <select 
                                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-semibold focus:outline-none focus:border-upl-blue focus:bg-white transition-all appearance-none"
                                    value={(formData as any)[field.key!]}
                                    onChange={(e) => setFormData({ ...formData, [field.key!]: e.target.value })}
                                  >
                                    <option value="">Select Type</option>
                                    {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                  </select>
                                ) : (
                                  <input 
                                    type={field.type || 'text'}
                                    readOnly={field.readOnly}
                                    placeholder={field.placeholder}
                                    className={`w-full ${field.readOnly ? 'bg-slate-100 text-slate-500 cursor-not-allowed' : 'bg-slate-50'} border border-slate-200 rounded-xl px-4 py-3 text-sm font-semibold focus:outline-none focus:border-upl-blue focus:bg-white transition-all`}
                                    value={(field.key ? (formData as any)[field.key] : field.value) || ''}
                                    onChange={(e) => field.key && setFormData({ ...formData, [field.key]: e.target.value })}
                                  />
                                )}
                              </div>
                            ))}
                            <div className="md:col-span-2 lg:col-span-3 space-y-1.5">
                              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 pl-1">Order Description</label>
                              <textarea 
                                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 text-sm font-semibold focus:outline-none focus:border-upl-blue focus:bg-white transition-all h-24"
                                placeholder="Enter specific instructions or order notes..."
                                value={formData.description || ''}
                                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                              />
                            </div>
                          </div>
                        </div>

                        {/* Section: Billing & Shipping */}
                        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-8 space-y-6">
                          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                             <div className="flex items-center gap-3 text-upl-blue">
                              <MapPin className="w-6 h-6 border-2 border-upl-blue rounded-lg p-0.5" />
                              <h3 className="font-bold text-lg">Billing & Shipping Address</h3>
                            </div>
                            <label className="flex items-center gap-2 cursor-pointer group">
                              <input 
                                type="checkbox"
                                checked={formData.isShippingSameAsBilling}
                                onChange={(e) => {
                                  const same = e.target.checked;
                                  setFormData({ 
                                    ...formData, 
                                    isShippingSameAsBilling: same,
                                    shippingAddress: same ? { ...formData.billingAddress! } : formData.shippingAddress
                                  });
                                }}
                                className="w-5 h-5 rounded border-slate-300 text-upl-orange focus:ring-upl-orange cursor-pointer"
                              />
                              <span className="text-sm font-bold text-slate-500 group-hover:text-upl-blue transition-colors">Same as Billing</span>
                            </label>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                            {/* Billing */}
                            <div className="space-y-4">
                              <h4 className="text-xs font-black text-slate-300 uppercase tracking-widest border-l-4 border-upl-blue pl-3">Billing Address</h4>
                              <div className="space-y-4">
                                {['street', 'city', 'state', 'country', 'zipCode'].map((key) => (
                                  <div key={`billing-${key}`}>
                                    <input 
                                      placeholder={key.charAt(0).toUpperCase() + key.slice(1)}
                                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-semibold focus:outline-none focus:border-upl-blue focus:bg-white"
                                      value={(formData.billingAddress as any)[key]}
                                      onChange={(e) => {
                                        const newBilling = { ...formData.billingAddress!, [key]: e.target.value };
                                        setFormData({ 
                                          ...formData, 
                                          billingAddress: newBilling,
                                          shippingAddress: formData.isShippingSameAsBilling ? newBilling : formData.shippingAddress
                                        });
                                      }}
                                    />
                                  </div>
                                ))}
                              </div>
                            </div>
                            {/* Shipping */}
                            <div className={`space-y-4 transition-opacity duration-300 ${formData.isShippingSameAsBilling ? 'opacity-40 pointer-events-none' : 'opacity-100'}`}>
                              <h4 className="text-xs font-black text-slate-300 uppercase tracking-widest border-l-4 border-upl-orange pl-3">Shipping Address</h4>
                              <div className="space-y-4">
                                {['street', 'city', 'state', 'country', 'zipCode'].map((key) => (
                                  <div key={`shipping-${key}`}>
                                    <input 
                                      placeholder={key.charAt(0).toUpperCase() + key.slice(1)}
                                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-semibold focus:outline-none focus:border-upl-blue focus:bg-white"
                                      value={(formData.shippingAddress as any)[key]}
                                      onChange={(e) => setFormData({ ...formData, shippingAddress: { ...formData.shippingAddress!, [key]: e.target.value } })}
                                    />
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Section: Line Items */}
                        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                          <div className="p-8 pb-4 flex items-center justify-between border-b border-slate-100 bg-slate-50/50">
                            <div className="flex items-center gap-3 text-upl-blue">
                              <CheckSquare className="w-6 h-6 border-2 border-upl-blue rounded-lg p-0.5" />
                              <h3 className="font-bold text-lg">Line Items*</h3>
                            </div>
                            <button 
                              type="button"
                              onClick={() => setFormData({ 
                                ...formData, 
                                items: [...(formData.items || []), { id: Date.now().toString(), productName: '', sku: '', technicalName: '', quantity: 1, billingPrice: 0, discountPrice: 0 }] 
                              })}
                              className="text-upl-blue hover:text-white hover:bg-upl-blue px-4 py-2 rounded-xl text-sm font-bold border-2 border-upl-blue transition-all flex items-center gap-2"
                            >
                              <Plus className="w-4 h-4" />
                              Add New
                            </button>
                          </div>
                          
                          <div className="overflow-x-auto">
                            <table className="w-full text-left">
                              <thead>
                                <tr className="text-[10px] font-black text-slate-400 border-b border-slate-100 uppercase tracking-widest">
                                  <th className="px-6 py-4">Product Name*</th>
                                  <th className="px-6 py-4">SKU*</th>
                                  <th className="px-6 py-4">Technical Name</th>
                                  <th className="px-1 py-4 w-24">Qty*</th>
                                  <th className="px-6 py-4">Price*</th>
                                  <th className="px-6 py-4">Discount</th>
                                  <th className="px-6 py-4">Total</th>
                                  <th className="px-6 py-4 text-center">Action</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-50">
                                {formData.items?.map((item, idx) => (
                                  <tr key={item.id} className="group">
                                    <td className="px-6 py-3">
                                      <select 
                                        className="w-full bg-slate-50 border border-transparent hover:border-slate-200 rounded-lg px-3 py-2 text-sm font-semibold focus:outline-none focus:bg-white focus:border-upl-blue transition-all appearance-none"
                                        value={item.productName}
                                        onChange={(e) => {
                                          const selectedProd = PREDEFINED_PRODUCTS.find(p => p.name === e.target.value);
                                          const newItems = [...formData.items!];
                                          if (selectedProd) {
                                            newItems[idx] = {
                                              ...newItems[idx],
                                              productName: selectedProd.name,
                                              sku: selectedProd.sku,
                                              technicalName: selectedProd.technicalName,
                                              billingPrice: selectedProd.basePrice,
                                              discountPrice: Math.round(selectedProd.basePrice * 0.05), // Default 5% discount
                                            };
                                          } else {
                                            newItems[idx].productName = e.target.value;
                                          }
                                          setFormData({ ...formData, items: newItems });
                                        }}
                                      >
                                        <option value="">Select Product...</option>
                                        {PREDEFINED_PRODUCTS.map(p => (
                                          <option key={p.sku} value={p.name}>{p.name}</option>
                                        ))}
                                        <option value="custom">Other (Manual Entry)</option>
                                      </select>
                                    </td>
                                    <td className="px-6 py-3">
                                      <input 
                                        className="w-full bg-slate-100 border border-transparent rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-500"
                                        value={item.sku}
                                        readOnly
                                        placeholder="SKU"
                                      />
                                    </td>
                                    <td className="px-6 py-3">
                                      <input 
                                        className="w-full bg-slate-100 border border-transparent rounded-lg px-3 py-2 text-xs text-slate-500"
                                        value={item.technicalName}
                                        readOnly
                                        placeholder="Tech Name"
                                      />
                                    </td>
                                    <td className="px-1 py-3">
                                      <input 
                                        type="number"
                                        className="w-20 bg-slate-50 border border-transparent rounded-lg px-3 py-2 text-sm font-bold focus:outline-none focus:bg-white transition-all"
                                        value={item.quantity}
                                        onChange={(e) => {
                                          const newItems = [...formData.items!];
                                          newItems[idx].quantity = parseInt(e.target.value) || 0;
                                          setFormData({ ...formData, items: newItems });
                                        }}
                                      />
                                    </td>
                                    <td className="px-6 py-3">
                                      <div className="relative">
                                        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">$</span>
                                        <input 
                                          type="number"
                                          className="w-full pl-6 bg-slate-50 border border-transparent rounded-lg px-3 py-2 text-sm font-bold focus:outline-none focus:bg-white transition-all"
                                          value={item.billingPrice}
                                          onChange={(e) => {
                                            const newItems = [...formData.items!];
                                            newItems[idx].billingPrice = parseFloat(e.target.value) || 0;
                                            setFormData({ ...formData, items: newItems });
                                          }}
                                        />
                                      </div>
                                    </td>
                                    <td className="px-6 py-3 text-red-500 font-bold">
                                      <div className="relative">
                                        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] font-bold text-red-300">$</span>
                                        <input 
                                          type="number"
                                          className="w-full pl-6 bg-slate-50 border border-transparent rounded-lg px-3 py-2 text-sm font-bold text-red-500 focus:outline-none focus:bg-white transition-all"
                                          value={item.discountPrice}
                                          onChange={(e) => {
                                            const newItems = [...formData.items!];
                                            newItems[idx].discountPrice = parseFloat(e.target.value) || 0;
                                            setFormData({ ...formData, items: newItems });
                                          }}
                                        />
                                      </div>
                                    </td>
                                    <td className="px-6 py-3 font-black text-slate-900">
                                      ${((item.billingPrice - item.discountPrice) * item.quantity).toLocaleString()}
                                    </td>
                                    <td className="px-6 py-3 text-center">
                                      <button 
                                        type="button"
                                        onClick={() => {
                                          const newItems = formData.items!.filter((_, i) => i !== idx);
                                          setFormData({ ...formData, items: newItems.length ? newItems : [{ id: '1', productName: '', sku: '', technicalName: '', quantity: 1, billingPrice: 0, discountPrice: 0 }] });
                                        }}
                                        className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>

                          <div className="p-8 bg-slate-50 flex justify-end">
                            <div className="w-80 space-y-3">
                              <div className="flex justify-between text-sm font-bold text-slate-500">
                                <span>Subtotal</span>
                                <span className="text-slate-900">${totals.subtotal.toLocaleString()}</span>
                              </div>
                              <div className="flex justify-between text-xs font-semibold text-slate-400">
                                <span>CGST (9%)</span>
                                <span>${totals.cgst.toLocaleString()}</span>
                              </div>
                              <div className="flex justify-between text-xs font-semibold text-slate-400">
                                <span>SGST (9%)</span>
                                <span>${totals.sgst.toLocaleString()}</span>
                              </div>
                              <div className="flex justify-between text-xs font-semibold text-slate-400 pb-3 border-b border-slate-200">
                                <span>IGST (13%)</span>
                                <span>${totals.igst.toLocaleString()}</span>
                              </div>
                              <div className="flex justify-between text-sm font-bold text-upl-blue">
                                <span>Tax Amount</span>
                                <span>${totals.tax.toLocaleString()}</span>
                              </div>
                              <div className="flex justify-between items-center text-xl font-black text-upl-blue pt-3">
                                <div className="flex flex-col">
                                  <span>Grand Total*</span>
                                  <span className="text-[10px] text-slate-400 uppercase tracking-widest font-black">Incl. Taxes</span>
                                </div>
                                <span className="text-2xl text-upl-orange">${totals.total.toLocaleString()}</span>
                              </div>
                            </div>
                            
                            {totals.total > currentAvailableCredit && (
                              <motion.div 
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                className="mt-6 p-4 bg-red-50 border border-red-200 rounded-2xl flex gap-4 items-center"
                              >
                                <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center flex-shrink-0">
                                  <AlertCircle className="w-6 h-6 text-red-500" />
                                </div>
                                <div>
                                  <p className="text-sm font-black text-red-700">CREDIT LIMIT EXCEEDED</p>
                                  <p className="text-xs text-red-600/70">Your order total (${totals.total.toLocaleString()}) exceeds your available credit ($${currentAvailableCredit.toLocaleString()}). Submission blocked.</p>
                                </div>
                              </motion.div>
                            )}
                          </div>

                          <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-end gap-4">
                             <button 
                              type="button"
                              onClick={() => setIsAddingOrder(false)}
                              className="px-8 py-4 rounded-xl font-bold text-slate-500 hover:bg-slate-200 transition-colors"
                            >
                              Save as Draft
                            </button>
                            <button 
                              type="submit"
                              disabled={totals.total > currentAvailableCredit}
                              className={`
                                px-10 py-4 rounded-xl font-black text-white shadow-2xl transition-all flex items-center justify-center gap-3
                                ${totals.total > currentAvailableCredit 
                                  ? 'bg-slate-300 cursor-not-allowed opacity-50' 
                                  : 'bg-gradient-to-r from-upl-blue to-blue-800 shadow-blue-800/20 hover:scale-[1.02] active:scale-[0.98]'}
                              `}
                            >
                              <ShoppingBag className="w-5 h-5" />
                              CONFIRM & PLACE ORDER
                            </button>
                          </div>
                        </div>
                      </form>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Order Detail Modal */}
                <AnimatePresence>
                  {selectedOrder && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={() => setSelectedOrder(null)}
                        className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" 
                      />
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.9, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, y: 20 }}
                        className="relative bg-white w-full max-w-4xl max-h-[90vh] rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col"
                      >
                        {/* Modal Header */}
                        <div className="shrink-0 bg-gradient-to-r from-upl-orange to-orange-600 p-8 flex justify-between items-start">
                          <div className="flex items-center gap-4">
                            <div className="bg-white/20 p-3 rounded-2xl backdrop-blur-sm">
                              <ShoppingBag className="w-8 h-8 text-white" />
                            </div>
                            <div>
                              <div className="flex items-center gap-3">
                                <h2 className="text-2xl font-black text-white">Order Details</h2>
                                <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest bg-white/20 text-white`}>
                                  {selectedOrder.status}
                                </span>
                              </div>
                              <p className="text-orange-100/60 font-mono text-sm mt-1">{selectedOrder.id}</p>
                            </div>
                          </div>
                          <button 
                            onClick={() => setSelectedOrder(null)}
                            className="p-2 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-all"
                          >
                            <X className="w-6 h-6" />
                          </button>
                        </div>

                        {/* Modal Scrollable Content */}
                        <div className="flex-1 overflow-y-auto p-10 space-y-10">
                          {/* Top Row: Quick Info */}
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                            {[
                              { label: 'Order Date', value: selectedOrder.orderDate, icon: Calendar },
                              { label: 'Due Date', value: selectedOrder.dueDate || 'N/A', icon: Clock },
                              { label: 'Plant', value: selectedOrder.plant, icon: MapPin },
                              { label: 'Total Value', value: `$${selectedOrder.grandTotal.toLocaleString()}`, icon: AlertCircle },
                            ].map((stat) => (
                              <div key={stat.label} className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-1.5">
                                  <stat.icon className="w-3 h-3 text-upl-orange" />
                                  {stat.label}
                                </p>
                                <p className="text-sm font-black text-slate-900">{stat.value}</p>
                              </div>
                            ))}
                          </div>

                          {/* Addresses Section */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="space-y-4">
                              <h4 className="text-xs font-black text-upl-orange uppercase tracking-widest flex items-center gap-2">
                                <div className="w-1.5 h-1.5 rounded-full bg-upl-orange" />
                                Billing Information
                              </h4>
                              <div className="p-5 bg-white border border-slate-200 rounded-2xl space-y-1">
                                <p className="text-sm font-bold text-slate-800">{selectedOrder.billingAddress.street}</p>
                                <p className="text-sm text-slate-500">
                                  {selectedOrder.billingAddress.city}, {selectedOrder.billingAddress.state}
                                </p>
                                <p className="text-sm text-slate-500">
                                  {selectedOrder.billingAddress.country} - {selectedOrder.billingAddress.zipCode}
                                </p>
                              </div>
                            </div>
                            <div className="space-y-4">
                              <h4 className="text-xs font-black text-upl-orange uppercase tracking-widest flex items-center gap-2">
                                <div className="w-1.5 h-1.5 rounded-full bg-upl-orange" />
                                Shipping Information
                              </h4>
                              <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-1">
                                {selectedOrder.isShippingSameAsBilling ? (
                                  <p className="text-sm font-bold text-slate-400 italic">Same as billing address</p>
                                ) : (
                                  <>
                                    <p className="text-sm font-bold text-slate-800">{selectedOrder.shippingAddress.street}</p>
                                    <p className="text-sm text-slate-500">
                                      {selectedOrder.shippingAddress.city}, {selectedOrder.shippingAddress.state}
                                    </p>
                                    <p className="text-sm text-slate-500">
                                      {selectedOrder.shippingAddress.country} - {selectedOrder.shippingAddress.zipCode}
                                    </p>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Items Section */}
                          <div className="space-y-4">
                            <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                              <Package className="w-4 h-4" />
                              Order Line Items
                            </h4>
                            <div className="bg-white border border-slate-100 rounded-2xl overflow-hidden">
                              <table className="w-full text-left">
                                <thead className="bg-slate-50/50">
                                  <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
                                    <th className="px-6 py-4">Product Details</th>
                                    <th className="px-6 py-4 text-center">Quantity</th>
                                    <th className="px-6 py-4">Unit Price</th>
                                    <th className="px-6 py-4 text-right">Total</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-50">
                                  {selectedOrder.items.length > 0 ? selectedOrder.items.map((item) => (
                                    <tr key={item.id}>
                                      <td className="px-6 py-4">
                                        <p className="text-sm font-bold text-upl-orange">{item.productName}</p>
                                        <p className="text-[10px] text-slate-400 font-mono font-bold mt-0.5">{item.sku}</p>
                                      </td>
                                      <td className="px-6 py-4 text-center font-bold text-slate-600">{item.quantity}</td>
                                      <td className="px-6 py-4 font-semibold text-slate-900">${item.billingPrice.toLocaleString()}</td>
                                      <td className="px-6 py-4 text-right font-black text-slate-950">${((item.billingPrice - item.discountPrice) * item.quantity).toLocaleString()}</td>
                                    </tr>
                                  )) : (
                                    <tr>
                                      <td colSpan={4} className="px-6 py-10 text-center text-slate-400 italic">No line items recorded for this sample order.</td>
                                    </tr>
                                  )}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>

                        {/* Modal Footer Summary */}
                        <div className="shrink-0 bg-slate-50 border-t border-slate-100 p-8 flex justify-between items-center">
                          <div className="flex gap-10">
                            <div>
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Order Type</p>
                                <p className="text-sm font-bold text-slate-700">{selectedOrder.orderType || 'N/A'}</p>
                            </div>
                            <div>
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Contact Person</p>
                                <p className="text-sm font-bold text-slate-700">{selectedOrder.contactName || 'Lokesh Prasad'}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-xs font-black text-slate-400 uppercase tracking-widest mr-4">Grand Total</span>
                            <span className="text-4xl font-black text-upl-orange">${selectedOrder.grandTotal.toLocaleString()}</span>
                          </div>
                        </div>
                      </motion.div>
                    </div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {activeTab === 'invoices' && (
              <div className="space-y-8">
                <div className="flex flex-col gap-2">
                  <h1 className="text-3xl font-bold text-upl-blue">Financial Invoices</h1>
                  <p className="text-slate-500">Manage your billing records and track payment history with precision.</p>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {invoices.map((inv) => (
                    <motion.div 
                      key={inv.id}
                      whileHover={{ scale: 1.01 }}
                      className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md hover:border-upl-orange/20 transition-all p-6 group cursor-pointer"
                      onClick={() => setSelectedInvoice(inv)}
                    >
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                        <div className="flex items-center gap-5">
                          <div className="w-14 h-14 rounded-2xl bg-blue-50 flex items-center justify-center text-upl-blue group-hover:bg-upl-orange group-hover:text-white transition-colors duration-300">
                            <FileText className="w-7 h-7" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-lg font-black text-upl-blue group-hover:text-upl-orange transition-colors">{inv.invoiceNumber}</span>
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${inv.status === 'Approved' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                {inv.status}
                              </span>
                            </div>
                            <p className="text-sm font-medium text-slate-500 flex items-center gap-2">
                              <Calendar className="w-3.5 h-3.5" />
                              {inv.invoiceDate}
                              <span className="w-1 h-1 rounded-full bg-slate-300" />
                              <span className="text-xs uppercase font-bold text-slate-400">SAP: {inv.sapId}</span>
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-8 pl-14 md:pl-0">
                          <div className="text-right">
                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Total Amount</p>
                            <p className="text-2xl font-black text-slate-900 group-hover:text-upl-orange transition-colors leading-none">${inv.grandTotal.toLocaleString()}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <button className="hidden sm:flex p-2 text-slate-300 group-hover:text-upl-orange group-hover:bg-orange-50 rounded-xl transition-all">
                              <ArrowRight className="w-5 h-5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                {invoices.length === 0 && (
                  <div className="p-20 flex flex-col items-center justify-center text-slate-400">
                    <FileText className="w-16 h-16 mb-4 opacity-10" />
                    <p className="text-lg font-medium">No invoices found.</p>
                  </div>
                )}

                {/* Detailed View Modal */}
                <AnimatePresence>
                  {selectedInvoice && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={() => setSelectedInvoice(null)}
                        className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" 
                      />
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.9, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, y: 20 }}
                        className="relative bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden"
                      >
                        {/* Modal Header */}
                        <div className="h-32 bg-gradient-to-r from-upl-orange to-orange-400 p-8 flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-3">
                              <div className="bg-white/20 p-2 rounded-xl">
                                <FileText className="w-6 h-6 text-white" />
                              </div>
                              <h2 className="text-2xl font-black text-white">Invoice Details</h2>
                            </div>
                            <p className="text-orange-50/80 text-sm font-medium mt-1 ml-11">{selectedInvoice.invoiceNumber}</p>
                          </div>
                          <button 
                            onClick={() => setSelectedInvoice(null)}
                            className="p-2 bg-white/20 hover:bg-white/40 rounded-xl text-white transition-all backdrop-blur-sm"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        </div>

                        {/* Modal Body */}
                        <div className="p-10 pt-8 space-y-8 bg-gradient-to-b from-orange-50/30 to-white">
                          <div className="flex justify-between items-center border-b border-orange-100 pb-6">
                            <div className="space-y-1">
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Current Status</p>
                              <span className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider ${selectedInvoice.status === 'Approved' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                {selectedInvoice.status === 'Approved' ? <CircleCheck className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                                {selectedInvoice.status}
                              </span>
                            </div>
                            <div className="text-right">
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Payment Amount</p>
                              <p className="text-4xl font-black text-upl-orange">${selectedInvoice.grandTotal.toLocaleString()}</p>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-x-12 gap-y-8">
                            <div>
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">SAP Transaction ID</p>
                              <p className="text-sm font-bold text-slate-900 font-mono tracking-tight bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100 inline-block">{selectedInvoice.sapId}</p>
                            </div>
                            <div>
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Unique Record ID</p>
                              <p className="text-sm font-bold text-slate-900 font-mono tracking-tight">{selectedInvoice.id}</p>
                            </div>
                            <div>
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Invoice Date</p>
                              <p className="text-sm font-bold text-slate-900 flex items-center gap-2">
                                <Calendar className="w-4 h-4 text-upl-orange" />
                                {selectedInvoice.invoiceDate}
                              </p>
                            </div>
                            <div>
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Related Order</p>
                              <button 
                                onClick={() => {
                                  setHighlightedOrderId(selectedInvoice.orderId);
                                  setActiveTab('orders');
                                  setSelectedInvoice(null);
                                }}
                                className="text-sm font-black text-upl-blue hover:text-upl-orange underline underline-offset-4 decoration-2 decoration-upl-blue/30 hover:decoration-upl-orange/30 transition-all flex items-center gap-1.5 text-left"
                              >
                                {selectedInvoice.orderId}
                                <ArrowRight className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <div className="col-span-2">
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Distributor Name</p>
                              <div className="flex items-center gap-3 bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                                <div className="w-8 h-8 rounded-lg bg-orange-50 text-upl-orange flex items-center justify-center">
                                  <User className="w-4 h-4" />
                                </div>
                                <p className="text-sm font-bold text-slate-900">{selectedInvoice.distributorName}</p>
                              </div>
                            </div>
                          </div>

                          {/* Actions */}
                          <div className="pt-6 grid grid-cols-2 gap-4">
                            <button className="flex items-center justify-center gap-2 py-4 rounded-2xl border-2 border-slate-200 text-slate-500 font-bold hover:bg-slate-50 hover:border-slate-300 transition-all">
                              <FileText className="w-5 h-5 text-upl-orange" />
                              Download PDF
                            </button>
                            <button className="flex items-center justify-center gap-2 py-4 rounded-2xl bg-upl-orange text-white font-black shadow-xl shadow-upl-orange/30 hover:scale-[1.02] active:scale-95 transition-all">
                              Pay Now
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    </div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {activeTab === 'grm' && (
              <div className="space-y-8">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                  <div className="flex flex-col gap-2">
                    <h1 className="text-3xl font-bold text-upl-blue">Goods Receipt Management</h1>
                    <p className="text-slate-500">Live tracking and proof of delivery for your active shipments.</p>
                  </div>
                  <div className="flex items-center gap-3 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm">
                    <div className="bg-emerald-50 text-emerald-600 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-2">
                      <Activity className="w-4 h-4 animate-pulse" />
                      Live Network
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  {/* Left Column: Shipment List */}
                  <div className="lg:col-span-4 space-y-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest">Active Shipments</h3>
                      <span className="bg-upl-blue text-white text-[10px] px-2 py-0.5 rounded-full font-black">{orders.filter(o => o.status !== 'Draft').length}</span>
                    </div>
                    
                    <div className="space-y-3 overflow-y-auto max-h-[calc(screen-200px)]">
                      {orders.filter(o => o.status !== 'Draft').map((order) => {
                        const isActive = selectedTrackingOrderId === order.id;
                        return (
                          <button
                            key={order.id}
                            onClick={() => setSelectedTrackingOrderId(order.id)}
                            className={`
                              w-full text-left p-5 rounded-3xl border transition-all duration-300 group relative overflow-hidden
                              ${isActive 
                                ? 'bg-upl-blue border-upl-blue shadow-xl shadow-blue-900/20' 
                                : 'bg-white border-slate-200 hover:border-upl-blue/30 shadow-sm'}
                            `}
                          >
                            {isActive && (
                              <motion.div 
                                layoutId="activeShipment"
                                className="absolute left-0 top-0 bottom-0 w-1.5 bg-upl-orange"
                              />
                            )}
                            <div className="flex justify-between items-start mb-3">
                              <div className={`p-2 rounded-xl transition-colors ${isActive ? 'bg-white/10 text-white' : 'bg-slate-100 text-slate-400'}`}>
                                <Truck className="w-5 h-5" />
                              </div>
                              <span className={`text-[10px] font-black uppercase tracking-widest ${isActive ? 'text-blue-100' : 'text-slate-400'}`}>
                                {order.status}
                              </span>
                            </div>
                            <h4 className={`font-black text-lg ${isActive ? 'text-white' : 'text-upl-blue'}`}>{order.id}</h4>
                            <p className={`text-xs font-medium mt-1 ${isActive ? 'text-blue-200' : 'text-slate-500'}`}>
                              Distributor: {order.distributorName}
                            </p>
                            <div className="mt-4 flex justify-between items-center">
                              <p className={`text-sm font-black ${isActive ? 'text-white' : 'text-slate-900'}`}>${order.grandTotal.toLocaleString()}</p>
                              <div className={`flex items-center gap-1.5 text-[10px] font-bold ${isActive ? 'text-blue-300' : 'text-slate-400'}`}>
                                <Calendar className="w-3 h-3" />
                                {order.orderDate}
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Right Column: Tracking Detail */}
                  <div className="lg:col-span-8">
                    {selectedTrackingOrderId ? (() => {
                      const order = orders.find(o => o.id === selectedTrackingOrderId)!;
                      const isAtDoorstep = order.trackingStages[order.currentStageIndex]?.isStepAtDoorstep;
                      const isDelivered = order.status === 'Delivered';

                      return (
                        <div className="space-y-6">
                          {/* Main View Container */}
                          <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-xl overflow-hidden flex flex-col">
                            {/* Tracking Top Header */}
                            <div className="bg-slate-50 p-8 border-b border-slate-100 flex justify-between items-center">
                              <div className="flex items-center gap-4">
                                <div className="p-4 bg-white rounded-2xl shadow-sm border border-slate-100">
                                  <Activity className="w-8 h-8 text-upl-orange" />
                                </div>
                                <div>
                                  <div className="flex items-center gap-3">
                                    <h2 className="text-2xl font-black text-upl-blue">Shipment Tracking</h2>
                                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${isDelivered ? 'bg-emerald-100 text-emerald-600' : 'bg-blue-100 text-blue-600'}`}>
                                      {order.status}
                                    </span>
                                  </div>
                                  <p className="text-slate-400 text-sm font-mono mt-0.5">{order.id} • Registered to {order.distributorName}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-4">
                                <div className="text-right">
                                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Expected Delivery</p>
                                  <p className="text-lg font-black text-slate-900 leading-none">{order.dueDate || 'Calculated Soon'}</p>
                                </div>
                              </div>
                            </div>

                            <div className="p-10 space-y-12">
                              {/* Horizontal Quick Progress */}
                              <div className="relative">
                                <div className="absolute top-1/2 left-0 right-0 h-1 bg-slate-100 -translate-y-1/2 rounded-full overflow-hidden">
                                  <motion.div 
                                    className="h-full bg-upl-orange"
                                    initial={{ width: 0 }}
                                    animate={{ width: `${(order.currentStageIndex / (order.trackingStages.length - 1)) * 100}%` }}
                                    transition={{ duration: 1, ease: "easeOut" }}
                                  />
                                </div>
                                <div className="relative flex justify-between">
                                  {order.trackingStages.map((stage, idx) => {
                                    const isCompleted = idx < order.currentStageIndex || (isDelivered && idx === order.currentStageIndex);
                                    const isCurrent = idx === order.currentStageIndex && !isDelivered;
                                    return (
                                      <div key={idx} className="flex flex-col items-center gap-3 relative z-10">
                                        <div className={`
                                          w-6 h-6 rounded-full border-4 transition-all duration-500
                                          ${isCompleted ? 'bg-upl-orange border-blue-50 scale-110' : ''}
                                          ${isCurrent ? 'bg-white border-upl-orange animate-pulse' : ''}
                                          ${!isCompleted && !isCurrent ? 'bg-white border-slate-200' : ''}
                                        `} />
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>

                              {/* Vertical Detailed Timeline */}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                                <div className="space-y-8">
                                  <div className="flex items-center gap-2 mb-6">
                                    <History className="w-5 h-5 text-upl-blue" />
                                    <h4 className="text-xs font-black text-upl-blue uppercase tracking-widest italic">Live History Log</h4>
                                  </div>
                                  
                                  <div className="space-y-10 relative">
                                    <div className="absolute left-[11px] top-4 bottom-4 w-0.5 bg-slate-100" />
                                    {order.trackingStages.slice().reverse().map((stage, idx, arr) => {
                                      const originalIdx = (arr.length - 1) - idx;
                                      const isCompleted = originalIdx <= order.currentStageIndex;
                                      const isActive = originalIdx === order.currentStageIndex;

                                      return (
                                        <div key={idx} className="flex gap-6 group">
                                          <div className={`
                                            w-6 h-6 rounded-full shrink-0 relative z-10 transition-all duration-300 flex items-center justify-center
                                            ${isActive ? 'bg-upl-orange ring-4 ring-orange-100' : isCompleted ? 'bg-emerald-500' : 'bg-slate-200'}
                                          `}>
                                            {isCompleted && originalIdx !== order.currentStageIndex && <CircleCheck className="w-3.5 h-3.5 text-white" />}
                                            {isActive && <div className="w-2 h-2 bg-white rounded-full animate-ping" />}
                                          </div>
                                          <div className="space-y-1.5 flex-1 pt-0.5">
                                            <div className="flex justify-between items-start">
                                              <p className={`text-sm font-black transition-colors ${isActive ? 'text-upl-orange' : isCompleted ? 'text-slate-900' : 'text-slate-400'}`}>
                                                {stage.label}
                                              </p>
                                              {stage.timestamp && (
                                                <p className="text-[10px] font-mono font-bold text-slate-400">{stage.timestamp}</p>
                                              )}
                                            </div>
                                            <p className="text-xs text-slate-500 font-medium">
                                              {stage.location || 'Pending carrier update'}
                                            </p>
                                          </div>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>

                                {/* EPOD Upload Area */}
                                <div className="flex flex-col justify-center">
                                  {isAtDoorstep && !isDelivered ? (
                                    <motion.div 
                                      initial={{ opacity: 0, y: 30 }}
                                      animate={{ opacity: 1, y: 0 }}
                                      className="p-8 bg-orange-50 border-2 border-dashed border-upl-orange/40 rounded-[2.5rem] text-center space-y-6"
                                    >
                                      <div className="w-20 h-20 bg-white rounded-3xl shadow-xl shadow-orange-900/10 flex items-center justify-center mx-auto mb-2">
                                        <FileUp className="w-10 h-10 text-upl-orange" />
                                      </div>
                                      <div className="space-y-2">
                                        <h3 className="text-xl font-black text-upl-blue italic">EPOD Required</h3>
                                        <p className="text-sm text-slate-600 font-medium">
                                          Your shipment has reached the destination doorstep. Please upload the proof of delivery to mark as received.
                                        </p>
                                      </div>
                                      
                                      <div className="pt-2">
                                        <input 
                                          type="file" 
                                          id="epod-file" 
                                          className="hidden" 
                                          onChange={(e) => {
                                            if (e.target.files && e.target.files[0]) {
                                              handleEpodUpload(order.id);
                                            }
                                          }}
                                        />
                                        <label 
                                          htmlFor="epod-file"
                                          className="flex items-center justify-center gap-3 w-full bg-upl-orange text-white py-5 rounded-2xl font-black shadow-2xl shadow-upl-orange/40 hover:bg-orange-600 transition-all cursor-pointer active:scale-95 group"
                                        >
                                          <Upload className="w-5 h-5 group-hover:-translate-y-1 transition-transform" />
                                          UPLOAD PROOF & DELIVER
                                        </label>
                                      </div>
                                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                        Standard UPL Compliance Protocol Required
                                      </p>
                                    </motion.div>
                                  ) : isDelivered ? (
                                    <div className="p-8 bg-emerald-50 border-2 border-emerald-100 rounded-[2.5rem] text-center space-y-4">
                                      <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mx-auto">
                                        <CircleCheck className="w-8 h-8 text-emerald-500" />
                                      </div>
                                      <div>
                                        <h3 className="text-lg font-black text-emerald-700">Delivery Confirmed</h3>
                                        <p className="text-xs text-emerald-600/80 font-medium mt-1">
                                          Proof of delivery has been verified and registered in the SAP system.
                                        </p>
                                      </div>
                                      <button className="text-[10px] font-black text-emerald-700 uppercase tracking-widest border-b border-emerald-200 pb-0.5 hover:border-emerald-700 transition-all">
                                        View EPOD Receipt
                                      </button>
                                    </div>
                                  ) : (
                                    <div className="p-10 border-2 border-dashed border-slate-100 rounded-[2.5rem] flex flex-col items-center gap-4 text-center opacity-40">
                                      <Clock className="w-12 h-12 text-slate-300" />
                                      <div>
                                        <p className="text-sm font-black text-slate-400 uppercase tracking-widest">Awaiting Doorstep</p>
                                        <p className="text-xs text-slate-500 max-w-[200px] mt-1">EPOD upload will be active once shipment reaches last mile.</p>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>

                            {/* Shipment Info Footer */}
                            <div className="bg-slate-900 p-8 flex flex-col md:flex-row justify-between items-center gap-6">
                              <div className="flex gap-10">
                                <div>
                                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Carrier Provider</p>
                                  <p className="text-sm font-bold text-white">UPL Logistics Logistics Core</p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Transit Weight</p>
                                  <p className="text-sm font-bold text-white">2.4 Tons</p>
                                </div>
                              </div>
                              <button className="flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-black transition-all">
                                <FileText className="w-4 h-4 text-upl-orange" />
                                DOWNLOAD MANIFEST
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })() : (
                      <div className="bg-white rounded-[2.5rem] border border-slate-200 border-dashed p-20 flex flex-col items-center justify-center text-slate-400">
                        <Truck className="w-20 h-20 mb-6 opacity-10" />
                        <h3 className="text-xl font-bold text-slate-300">Select a shipment to track</h3>
                        <p className="text-sm opacity-60 mt-2">Active shipments in transit will appear here for management.</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'profile' && (
              <div className="max-w-3xl mx-auto space-y-8">
                <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="h-32 bg-gradient-to-r from-upl-blue to-blue-600" />
                  <div className="px-8 pb-8">
                    <div className="flex justify-between items-end -mt-12 mb-6">
                      <div className="w-24 h-24 rounded-2xl bg-white p-1 shadow-md">
                        <div className="w-full h-full rounded-xl bg-slate-100 flex items-center justify-center text-upl-blue">
                          <User className="w-12 h-12" />
                        </div>
                      </div>
                      <button className="px-6 py-2 rounded-lg border border-slate-200 text-sm font-bold hover:bg-slate-50 transition-colors">
                        Edit Profile
                      </button>
                    </div>
                    <div className="space-y-1">
                      <h2 className="text-2xl font-bold text-upl-blue">Lokesh Prasad</h2>
                      <p className="text-slate-500">Authorized Distributor • Mumbai, India</p>
                    </div>
                    <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                        <p className="text-[10px] uppercase tracking-wider font-bold text-slate-400 mb-1">Email Settings</p>
                        <p className="text-sm font-semibold">lokesh.p@distributor.upl.com</p>
                      </div>
                      <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                        <p className="text-[10px] uppercase tracking-wider font-bold text-slate-400 mb-1">Contact Number</p>
                        <p className="text-sm font-semibold">+91 98765 43210</p>
                      </div>
                    </div>
                    <div className="mt-8">
                      <button className="w-full bg-upl-orange text-white px-6 py-4 rounded-2xl font-bold shadow-xl shadow-upl-orange/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2">
                        <Bell className="w-5 h-5" />
                        Contact Support Admin
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'privacy' && (
              <div className="max-w-4xl mx-auto space-y-12">
                <div className="text-center space-y-4">
                  <div className="w-20 h-20 bg-upl-blue/5 rounded-3xl flex items-center justify-center mx-auto mb-6">
                    <Activity className="w-10 h-10 text-upl-blue" />
                  </div>
                  <h1 className="text-4xl font-black text-upl-blue italic">Privacy Policy</h1>
                  <p className="text-slate-400 font-medium">Last updated: May 11, 2026</p>
                </div>

                <div className="bg-white rounded-[3rem] border border-slate-200 p-12 shadow-xl space-y-10">
                  <section className="space-y-4">
                    <h2 className="text-xl font-black text-upl-blue uppercase tracking-widest flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-upl-orange" />
                      1. Data Collection
                    </h2>
                    <p className="text-slate-600 leading-relaxed font-medium">
                      UPL Ltd collects information that identifies, relates to, describes, or is reasonably capable of being associated with you. This includes distributor details, order history, and geographic territory information required for SAP integration and logistics fulfillment.
                    </p>
                  </section>
                  <section className="space-y-4">
                    <h2 className="text-xl font-black text-emerald-600 uppercase tracking-widest flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-emerald-500" />
                      2. Security Disclosure
                    </h2>
                    <p className="text-slate-600 leading-relaxed font-medium">
                      We utilize enterprise-grade security protocols (AES-256) to ensure your ordering data remains confidential. Access to this portal is restricted to authenticated partners only.
                    </p>
                  </section>
                  <p className="text-center text-[10px] font-black text-slate-300 uppercase tracking-widest">End of Document</p>
                </div>
              </div>
            )}

            {activeTab === 'terms' && (
              <div className="max-w-4xl mx-auto space-y-12">
                <div className="text-center space-y-4">
                  <div className="w-20 h-20 bg-orange-50 rounded-3xl flex items-center justify-center mx-auto mb-6">
                    <CheckSquare className="w-10 h-10 text-upl-orange" />
                  </div>
                  <h1 className="text-4xl font-black text-upl-blue italic">Terms of Service</h1>
                  <p className="text-slate-400 font-medium">Distributor Agreement v4.2</p>
                </div>

                <div className="bg-white rounded-[3rem] border border-slate-200 p-12 shadow-xl space-y-8">
                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200">
                    <h3 className="font-bold text-slate-900 mb-2">Usage Agreement</h3>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      By utilizing the UPL Distributor Portal, you agree to abide by our fair credit policies. Orders are legally binding once they reach the "Processing" stage in our SAP backend.
                    </p>
                  </div>
                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200">
                    <h3 className="font-bold text-slate-900 mb-2">EPOD Compliance</h3>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      All shipments must have a valid Electronic Proof of Delivery (EPOD) uploaded within 12 hours of arrival to the doorstep to maintain logistics priority.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer / Contact Widget */}
      <footer className="bg-white border-t border-slate-200 py-6">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center text-slate-400 text-xs font-medium">
          <p>© 2026 UPL Limited. All rights reserved.</p>
          <div className="flex gap-10">
            <button 
              onClick={() => setActiveTab('privacy')}
              className={`hover:text-upl-orange transition-colors uppercase tracking-widest leading-none mt-1 ${activeTab === 'privacy' ? 'text-upl-orange' : ''}`}
            >
              Privacy Policy
            </button>
            <button 
              onClick={() => setActiveTab('terms')}
              className={`hover:text-upl-orange transition-colors uppercase tracking-widest leading-none mt-1 ${activeTab === 'terms' ? 'text-upl-orange' : ''}`}
            >
              Terms of Service
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
